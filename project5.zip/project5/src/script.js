const fleft = document.getElementById('fleft');
const cards = document.querySelectorAll('.fleftlm');
const imgs = document.querySelectorAll('#fright .images img');

imgs[0].classList.add('show');

const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            const index = Array.from(cards).indexOf(entry.target);

            imgs.forEach((img) => img.classList.remove('show'));
            imgs[index].classList.add('show');
        }
    });
}, { root: fleft, threshold: 0.6 });

cards.forEach((card) => observer.observe(card));